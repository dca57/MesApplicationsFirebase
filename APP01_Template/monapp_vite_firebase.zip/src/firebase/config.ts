import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

// 🛑 CONFIGURATION MANUELLE OBLIGATOIRE
// Collez vos clés Firebase ci-dessous.
// Ne laissez PAS les valeurs "REMPLACEZ_MOI_...".

const firebaseConfig = {
  apiKey: "AIzaSyBUFeLriwkzMSW1tq6u9Lx12PwG2aCovSg",
  authDomain: "mesappsfirebase.firebaseapp.com",
  projectId: "mesappsfirebase",
  storageBucket: "mesappsfirebase.firebasestorage.app",
  messagingSenderId: "730508285766",
  appId: "1:730508285766:web:baa0c9fb7976c46845b747",
};

// Validation de la configuration
const isValidConfig = 
  firebaseConfig.apiKey && 
  !firebaseConfig.apiKey.startsWith("REMPLACEZ_MOI") &&
  !firebaseConfig.apiKey.startsWith("AIzaSyBUFeLriwkzMSW1tq6u9Lx12PwG2aCovSg"); // Bloque l'ancienne clé de démo

if (!isValidConfig) {
  console.error("❌ ERREUR FATALE : Les clés Firebase ne sont pas configurées dans src/firebase/config.ts");
} else {
  console.log("✅ Firebase Config chargée avec succès");
}

// Initialisation sécurisée
let app;
try {
  if (isValidConfig) {
    app = initializeApp(firebaseConfig);
  } else {
    // Dummy app pour éviter le crash blanc, mais l'auth échouera proprement
    app = initializeApp({ apiKey: "dummy", appId: "dummy" }, "dummy-app");
  }
} catch (e) {
  console.error("Erreur init Firebase:", e);
}

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

export default app;